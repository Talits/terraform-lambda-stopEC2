
import boto3

ec2 = boto3.resource('ec2')

def lambda_handler(event, context):

    filters = [{
            'Name': 'tag:prod',
            'Values': ['false']
        },
        {
            'Name': 'instance-state-name', 
            'Values': ['running']
        }
    ]
    
    instances = ec2.instances.filter(Filters=filters)
    
    Running = [instance.id for instance in instances]
    if len(Running) > 0:
        stop= ec2.instances.filter(InstanceIds=Running).stop()
        print (stop)
    else:
        print ("Instances are already stopped")
